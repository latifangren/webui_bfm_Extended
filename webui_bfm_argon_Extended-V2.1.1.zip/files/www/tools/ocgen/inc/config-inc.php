<?php
// Versi OcGen
$versi = "1.2-beta";

// NAMA OcGen
$ocgen = "OcGen"; 

// Mendapatkan IP address
$ipAddress = $_SERVER['REMOTE_ADDR'];

// Mendapatkan hostname
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

// Official Github link
$github = "https://github.com/mitralola716/ocgen";


?>
