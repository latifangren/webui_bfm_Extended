<br>
	
<div id="app">
<div class="container">
	<div class="justify-content-md-center text-center" style="font-family:courier" align="center">
		<span class="text-primary"><i class="fa fa-server"></i> IP	: {{ wan_ip }}</span>
    </div>

	<div class="justify-content-md-center text-center" style="font-family:courier" align="center">
		<span class="text-primary"><i class="fa fa-flag-o"></i> ISP	: {{ wan_net }} | {{ wan_country }}</span>
	</div>
</div>
</div>