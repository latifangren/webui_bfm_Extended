
<br>
	
<div id="app">
	<div class="col-lg-12 col-md-12" style="font-family:courier">
		<span class="text-primary"><i class="fa fa-server"></i> IP	: {{ wan_ip }}</span>
    </div>

	<div class="col-lg-12 col-md-12" style="font-family:courier">
		<span class="text-primary"><i class="fa fa-flag-o"></i> ISP	: {{ wan_net }} | {{ wan_country }}</span>
    </div>
	
</div>