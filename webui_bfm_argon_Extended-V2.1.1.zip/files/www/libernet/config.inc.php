<?php
    $libernet_dir = "/data/adb/php7/files/bin/libernet";
?>
