<footer class="text-center">
    <font color="white">© 2021-2022 Libernet Plus v1.5.5.</a>
</footer>
